﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;

namespace Wpf_Chatting_server
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        private TcpListener _listener;
        private static List<User> clients = new List<User>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            _listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 8080);
            _listener.Start();  //서버 실행, 위에서 설정한 아이피와 포트로 서버 실행 
                                //클라이언트가 접근할 때까지, 대기
            server_view.AppendText("\n           @@@ 서버가 작동중입니다. @@@\n");
            int i = 0;
            while (true)    // i < 10
            {
                TcpClient client = await _listener.AcceptTcpClientAsync(); //클라가 저 아이피와 포트로 연결할 때까지 여기서 대기, 그래서 메인 스레드가 여기서 블라킹, 만약 스레드가 접근하면 다음으로 진행
                
                User user = new User(client);

                clients.Add(user);

                user_list.Items.Add(clients[i].id);

                HandleClient(clients[i]);
                i++;
            }
            
        }
        
        private async Task HandleClient(User user)
        {
            Broadcast_id(user);

            NetworkStream stream = user.client.GetStream();
            byte[] sizeBuffer = new byte[4] { 0, 0, 0, 0 }; //Read하려면 버퍼가 필요하니까 버퍼의 크기를 임의로 1024로 준다.

           // user.broadcast


            int read;
            

            while (true)
            {
                //메세지 size 파악

                read = await stream.ReadAsync(sizeBuffer, 0, sizeBuffer.Length);    //설정된 size를 먼저 read
                if (read == 0)
                    break;
                int size = BitConverter.ToInt32(sizeBuffer,0);    // write 메시지의 크기를 미리 저장

                //메세지 출력

                byte[] buffer = new byte[size]; // 위에서 선언된 크기만큼의 버퍼를 생성
                read = await stream.ReadAsync(buffer, 0, buffer.Length);    // 생성된 버퍼 크기만큼만 데이터 read
                if (read == 0)
                    break;
                user.msg = Encoding.UTF8.GetString(buffer, 0, read);

                Broadcast_message(user.msg);
                
            }
        }
        private async Task Broadcast_id(User user)
        {
            NetworkStream stream = user.client.GetStream();  //getstream을 통해 stream을 통해서 데이터를 주고받을 수 있다.

            byte[] id_buffer = new byte[1024];
            int id_read = await stream.ReadAsync(id_buffer, 0, id_buffer.Length);
            string id = Encoding.UTF8.GetString(id_buffer, 0, id_read);
            Broadcast_message(" "+ user.id + "님이 입장하셨습니다.\n");
        }
        
        static void Broadcast_message(string message)
        {
            foreach (var user in clients)
            {
                NetworkStream stream = user.client.GetStream();
                byte[] c_message = Encoding.UTF8.GetBytes(message);
                stream.Write(c_message, 0, c_message.Length);
            }
        }
        class User
        {
            public TcpClient client;
            public string msg { get; set; }
            public string id { get; set; }
            public User(TcpClient client)
            {
                this.id = id;
                this.msg = msg;
                this.client = client;
            }
            public void broadcast(string msg)
            {
                foreach (var user in clients)
                {
                    NetworkStream stream = user.client.GetStream();
                    byte[] c_message = Encoding.UTF8.GetBytes(msg);
                    stream.Write(c_message, 0, c_message.Length);
                }
            }
        }
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Server_view_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
