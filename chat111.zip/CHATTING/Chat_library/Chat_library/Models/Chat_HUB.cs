﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Chat_library.Models
{
    public class Chat_HUB   //채팅을 할 때 정보를 주고받기 위한 클래스
    {
        
        public int User_ID { get; set; }
        public string User_Name { get; set; } = string.Empty;
        public int Room_ID { get; set; }
        public string Message { get; set; } = string.Empty;

        // JSON String으로 직렬화


    }
}
