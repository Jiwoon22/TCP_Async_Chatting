﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;

namespace Wpf_Chatting_client
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        private TcpClient _client;
        public MainWindow()
        {
            InitializeComponent(); 
        }

        private async void BtnConnect_Click(object sender, RoutedEventArgs e)   // 비동기 => async
        {
            _client = new TcpClient();

            string Server_IP = "127.0.0.1";//serverip_txt.Text;

            _client.ConnectAsync(IPAddress.Parse(Server_IP), 8080);   // 비동기 connect = ConncetAsync
                                                                        //  ㄴ> blocking 되지 않고 데이터 송수신
            HandleClient(_client);
        }
        private async Task HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();  //getstream을 통해 stream을 통해서 데이터를 주고받을 수 있다.
            byte[] buffer = new byte[1024]; //Read하려면 버퍼가 필요하니까 버퍼의 크기를 임의로 1024로 준다.
            int read;
            
            while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
            {
                string message = Encoding.UTF8.GetString(buffer, 0, read);

                chat_room.AppendText("\n"+message);

            }
        }
        private async void Send_btn_Click(object sender, RoutedEventArgs e)
        {
            NetworkStream stream = _client.GetStream(); //스트림을 이용해서 송수신을 한다.

            
            string text = Textbox1.Text;
          

            var message_buffer = Encoding.UTF8.GetBytes(text);  //write메서드에는 버퍼 인자가 필요하므로   텍스트를 버퍼로 변경해줘야한다.

            var messageLengthBuffer = BitConverter.GetBytes(message_buffer.Length);  //int형을 Byte로 변환
            
                stream.Write(messageLengthBuffer, 0, messageLengthBuffer.Length);   //보내고자 하는 데이터의 크기를 미리 서버에 write
                stream.Write(message_buffer, 0, message_buffer.Length);     // 서버에서 크기를 읽으면 그 크기만큼만 읽도록 함
            

        }
        private async Task ReceiveMessages(TcpClient client)
        {
            byte[] buffer = new byte[1024];
            int bytesRead;
            bytesRead = await client.GetStream().ReadAsync(buffer, 0, buffer.Length);
            string received_Message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            chat_room.AppendText("\n" + received_Message);
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Chat_room_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
